#define BG 46, 52, 64, 255
#define BG1 76, 86, 106, 255

#define RED 191,97,106
#define ORANGE 208,135,112
#define YELLOW 235,203,139 
#define GREEN 163,190,140
#define PURPLE 180,142,173
#define BLUE 94,129,172 
#define WHITE 255,255,255
#define BLACK 0,0,0
